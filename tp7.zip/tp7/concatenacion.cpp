#include <iostream>
#include <string> 

using namespace std;


string AC(const string& cadena1, const string& cadena2) {
    return cadena1 + cadena2;
}

int main() {
    string cadena1;
    cout<<"introduzca la palabra";
    cin>>cadena1;
    string cadena2;
      cout<<"introduzca la otra palabra";
    cin>>cadena2;
    
    string resultado = AC(cadena1, cadena2);
    cout << "La cadena concatenada es: " << resultado << endl;
    return 0;
}

