#include <iostream>
#include <string> 
using namespace std;


size_t LC(const string& cadena) {
    return cadena.length();
}

int main() {
    string cadena;
    cout<<"introducir palabra"<<endl;
    cin>>cadena;
    cout << "La longitud de la cadena es: " << LC(cadena) << endl;
    return 0;
}

